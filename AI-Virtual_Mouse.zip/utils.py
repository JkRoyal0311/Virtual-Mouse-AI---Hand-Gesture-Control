def smooth_coordinates(prev, new, alpha=0.2):
    """
    Exponential smoothing:
    prev = previous (x, y)
    new = new (x, y)
    alpha = smoothing factor (0 < alpha <= 1)
    """
    if prev is None:
        return new
    x = int(prev[0] + alpha * (new[0] - prev[0]))
    y = int(prev[1] + alpha * (new[1] - prev[1]))
    return (x, y)