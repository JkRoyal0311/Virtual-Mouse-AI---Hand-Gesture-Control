import cv2
import pyautogui
from hand_tracking import HandTracker
from gesture_logic import ScreenMapper, distance
from mouse_control import move_cursor, left_click, right_click, drag_start, drag_end, scroll
from utils import smooth_coordinates

# ---------------------------
# Helper: detect which fingers are up
# ---------------------------
def fingers_up(hand, w, h):
    """
    Returns a list of 5 values: 1 if finger is up, 0 if down
    Order: [thumb, index, middle, ring, pinky]
    """
    
    fingers = []

    # Thumb
    if hand.landmark[4].x < hand.landmark[3].x:
        fingers.append(1)
    else:
        fingers.append(0)

    # Fingers (index, middle, ring, pinky)
    tips = [8, 12, 16, 20]
    pip_joints = [6, 10, 14, 18]

    for tip, pip in zip(tips, pip_joints):
        if hand.landmark[tip].y < hand.landmark[pip].y:
            fingers.append(1)
        else:
            fingers.append(0)

    return fingers

# ---------------------------
# Main Virtual Mouse
# ---------------------------
def main():
    cap = cv2.VideoCapture(0)
    tracker = HandTracker()

    cam_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    cam_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    screen_w, screen_h = pyautogui.size()

    mapper = ScreenMapper((screen_w, screen_h), (cam_w, cam_h))

    click_threshold = 40
    click_state = False
    dragging = False
    prev_cursor = None  # store last cursor position

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        results = tracker.process(frame)
        tracker.draw(frame, results)

        if results.multi_hand_landmarks:
            hand = results.multi_hand_landmarks[0]
            h, w, _ = frame.shape

            # Finger tips
            index_tip = (int(hand.landmark[8].x * w), int(hand.landmark[8].y * h))
            thumb_tip = (int(hand.landmark[4].x * w), int(hand.landmark[4].y * h))

            # Map index tip to screen coordinates
            x_screen, y_screen = mapper.cam_to_screen(*index_tip)
            smoothed = smooth_coordinates(prev_cursor, (x_screen, y_screen), alpha=0.2)
            prev_cursor = smoothed

            move_cursor(*smoothed)

            # Draw visual feedback
            cv2.circle(frame, index_tip, 8, (0, 255, 255), -1)
            cv2.circle(frame, thumb_tip, 8, (255, 0, 255), -1)
            cv2.line(frame, index_tip, thumb_tip, (200, 200, 200), 2)

            # Pinch distance
            d = distance(index_tip, thumb_tip)

            # Left Click (Pinch)
            if d < click_threshold and not click_state:
                left_click()
                click_state = True
                cv2.putText(frame, "Click!", (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            elif d >= click_threshold:
                click_state = False

            # Fingers state
            fingers = fingers_up(hand, w, h)

            # Right Click (Index + Middle Up)
            if fingers[1] == 1 and fingers[2] == 1 and sum(fingers) == 2:
                right_click()
                cv2.putText(frame, "Right Click", (10, 90),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

            # Drag & Drop (Pinch and Hold)
            if d < click_threshold:
                if not dragging:
                    drag_start()
                    dragging = True
                    cv2.putText(frame, "Drag Start", (10, 120),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            else:
                if dragging:
                    drag_end()
                    dragging = False
                    cv2.putText(frame, "Drag End", (10, 120),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

            # Scroll (Two fingers up, move vertically)
            if fingers[1] == 1 and fingers[2] == 1 and sum(fingers) == 2:
                if prev_cursor:
                    dy = index_tip[1] - prev_cursor[1]
                    if abs(dy) > 5:
                        scroll(-int(dy))  # negative = scroll up

        cv2.imshow("Virtual Mouse - Smoothed", frame)
        if cv2.waitKey(1) & 0xFF == 27:  # ESC to quit
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
