import numpy as np

class ScreenMapper:
    def __init__(self, screen_size, cam_size, margin_ratio=0.1):
        self.screen_w, self.screen_h = screen_size
        self.cam_w, self.cam_h = cam_size
        self.mx = int(self.cam_w * margin_ratio)
        self.my = int(self.cam_h * margin_ratio)
        self.roi_w = self.cam_w - 2 * self.mx
        self.roi_h = self.cam_h - 2 * self.my

    def cam_to_screen(self, x_cam, y_cam):
        # Clamp to ROI
        x_clamped = np.clip(x_cam, self.mx, self.cam_w - self.mx)
        y_clamped = np.clip(y_cam, self.my, self.cam_h - self.my)
        # Normalize
        nx = (x_clamped - self.mx) / self.roi_w
        ny = (y_clamped - self.my) / self.roi_h
        # Map to screen
        return int(nx * self.screen_w), int(ny * self.screen_h)
    

def distance(p1, p2):
    return np.linalg.norm(np.array(p1) - np.array(p2))