import pyautogui

def move_cursor(x, y):
    pyautogui.moveTo(x, y)

def left_click():
    pyautogui.click()

def right_click():
    pyautogui.click(button='right')

def drag_start():
    pyautogui.mouseDown()

def drag_end():
    pyautogui.mouseUp()

def scroll(amount):
    pyautogui.scroll(amount)
